angular.module('hw8').controller('RefreshCtrl',RefreshCtrl);

function RefreshCtrl ($scope, $log, $http, $rootScope, $sce) {
    var self = this;
    self.news = [];
    self.price = [];
    self.inds = ["Price","SMA","EMA","STOCH","RSI","ADX","CCI","BBANDS","MACD"];
    self.cur_stock = true;
    $rootScope.$on("get_quote", getQuote);
    $rootScope.$on("get_inds", getInds);
    $rootScope.$on("get_news", getnews);

    function getQuote()
    {
        self.page = '2';
        self.wait_html   ='<div class="progress">' +
            ' <div class="progress-bar w-75" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>' +
            '</div>';
        self.indicators_html = $sce.trustAsHtml(self.wait_html);
        self.cur_stock_html = $sce.trustAsHtml(self.wait_html);
    }

    function getInds(){
        self.ind_json = $rootScope.ids;

    }
    function pro_price(){
        self.price["Stock Ticker Symbol"] = ;
    }
    function pro_news(){
        self.news = [];
        for (var i = 0; i < 5; i++)
        {
            var tmp = {"title":self.news_json["data"]["rss"]["channel"][0]["item"][i]["title"].toString(),
            "pubDate" : self.news_json["data"]["rss"]["channel"][0]["item"][i]["pubDate"].toString(),
            "link":self.news_json["data"]["rss"]["channel"][0]["item"][i]["link"].toString(),
            "author":self.news_json["data"]["rss"]["channel"][0]["item"][i]["sa:author_name"].toString()
                };
            // $log.info(tmp);
            self.news.push(tmp);
        }
    }
    function getnews(){
        self.news_json = $rootScope.news;
        $log.info(self.news_json);
        pro_news();
        $log.info(self.news);
    }

    function renderInds(){

    }

}