angular.module('hw8').controller('RefreshCtrl',RefreshCtrl);

function RefreshCtrl ($scope, $log, $http, $rootScope) {



}