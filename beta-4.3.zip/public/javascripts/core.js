    'use strict';

    angular.module('hw8',["ng","ngAnimate","ngAria",'ngMaterial', 'ngMessages']);
