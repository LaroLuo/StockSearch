angular.module('hw8').controller('RefreshCtrl',RefreshCtrl);

function RefreshCtrl ($scope, $log, $http, $rootScope, $sce) {
    var self = this;
    self.news = [];
    self.price = [];
    self.inds = ["Price","SMA","EMA","STOCH","RSI","ADX","CCI","BBANDS","MACD"];
    self.cur_stock = true;
    $rootScope.$on("get_quote", getQuote);
    $rootScope.$on("get_inds", getInds);
    $rootScope.$on("get_news", getnews);

    function getQuote()
    {
        self.page = '2';
        self.wait = true;
        self.wait_indicators = true;
        self.cur_form = false;
        self.tmp_html   ='<div class="progress">' +
            ' <div class="progress-bar w-75 progress-bar-striped" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>' +
            '</div>';
        self.wait_html = $sce.trustAsHtml(self.tmp_html);
    }

    function getInds(){
        self.ind_json = $rootScope.ids;
        self.cur_form = true;
        self.wait = false;
        self.wait_indicators = false;
        pro_price();
        $log.info(self.price)


    }
    function numberWithCommas(x) {
        var parts = x.toString().split(".");
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        return parts.join(".");
    }
    function pro_price(){
        self.price = [];
        var jobj = JSON.parse($rootScope.ids["data"]["Price"]);
        $log.info(jobj["Meta Data"]);
        var pre_close = 0;
        var time = jobj["Meta Data"]["3. Last Refreshed"];
        for (var x in jobj["Time Series (Daily)"])
        {
            if (x === time)
                continue;
            else{
                pre_close = jobj["Time Series (Daily)"][x]["4. close"];
            }
        }

        var symbol = jobj["Meta Data"]["2. Symbol"];

        var last = jobj["Time Series (Daily)"][jobj["Meta Data"]["3. Last Refreshed"]];
        var volume = last["5. volume"];
        var open = last["1. open"];
        var low = last["3. low"];
        var high = last["2. high"];
        var close = last["4. close"];
        var change_price = parseFloat(pre_close) - parseFloat(close);
        var change_percent = Math.abs(change_price / parseFloat(pre_close));
        var change = change_price.toFixed(2).toString() + "(" + change_percent.toFixed(2).toString() + "%)";
        var range = low.toString() + " - " + high.toString();
        self.price.push({"key":"Stock Ticker Symbol",
            "value" : symbol});
        self.price.push({"key":"Last Price","value" : close});
        self.price.push({"key":"Change (Change Percent)","value"  : change});
        self.price.push({"key":"Timestamp" ,"value" : time});
        self.price.push({"key":"Open","value"  : open});
        self.price.push({"key":"Previous Close" ,"value" : pre_close});
        self.price.push({"key":"Daily Range","value"  : range});
        self.price.push({"key":"Volume","value" : numberWithCommas(volume)});
    }
    function pro_news(){
        self.news = [];
        for (var i = 0; i < 5 && i < self.news_json["data"]["rss"]["channel"][0]["item"].length ; i++)
        {
            var tmp = {"title":self.news_json["data"]["rss"]["channel"][0]["item"][i]["title"].toString(),
            "pubDate" : self.news_json["data"]["rss"]["channel"][0]["item"][i]["pubDate"].toString(),
            "link":self.news_json["data"]["rss"]["channel"][0]["item"][i]["link"].toString(),
            "author":self.news_json["data"]["rss"]["channel"][0]["item"][i]["sa:author_name"].toString()
                };
            // $log.info(tmp);
            self.news.push(tmp);
        }
    }
    function getnews(){
        self.news_json = $rootScope.news;
        $log.info(self.news_json);
        pro_news();
        $log.info(self.news);
    }

    function renderInds(){

    }

}